﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication1
{


    public partial class Form1 : Form
    {
        int recordCount = 0;

        // Use lList of record for sorting
        List<Record> Values = new List<Record>();

        
        public Form1()
        {
            InitializeComponent();
        }

        // Read and Process file.
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdiaglog = new OpenFileDialog();
            if (fdiaglog.ShowDialog() == DialogResult.OK)
            {
                String temp;
                float time;
                float volt;
                bool result;
                Record value;
                String[] words;
                int row = 0;
                FileStream fs;
                textBox1.Text = fdiaglog.FileName;

                //Read the contents of the file into a stream
                var fileStream = fdiaglog.OpenFile();
                String wfileStream;

                using (StreamReader reader = new StreamReader(fileStream))
                {
                    // Read line by line till end of file
                    while (reader.EndOfStream == false)
                    {
                        temp = reader.ReadLine();
                        //Skip first row, which contain column names
                        if (row == 0)
                        {
                            row++;
                            continue;
                        }
                        try
                        {

                            // split string o get time and volt values
                            words = temp.Split(',');

                            // change from string to float values
                            result = float.TryParse(words[0], out time);
                            result = float.TryParse(words[1], out volt);

                            // set record to add to list
                            value = new Record(time, volt);
                            Values.Add(new Record(value.Time, value.Volt));
                            recordCount++; // update record count used for debug if needed
                        }
                        catch
                        {
                            MessageBox.Show("Record string empty");
                            break;
                        }
                    }

                    // Sort record base on volt value
                    try
                    {
                        // Sort list base on volt in descending order (amplitude) value
                        Values.Sort(delegate(Record y, Record x)
                        {
                            return x.Volt.CompareTo(y.Volt);
                        });
                    }
                    catch
                    {
                        MessageBox.Show("List Values empty");
                    }
                    // close read file
                    reader.Close();
                    fileStream.Close()
                        ;
                    // Save sorted record back to file with prefixe "Sbefore the file extention csv
                    //String writeFileName 
                    wfileStream = fdiaglog.FileName;
                    wfileStream = wfileStream.Replace(".csv", "S.csv");

                   // MessageBox.Show(wfileStream);
                }
                // save sorted records to a file named <filename><S><.csv>
                using (StreamWriter sw = File.CreateText(wfileStream))
                {
                    string temp2;
                    try
                    {
                        // Save records in  List 
                        Values.ForEach(x =>
                        {
                            // formate time, volt <LF>
                            temp2 = x.Time.ToString() + ", " + x.Volt.ToString();
                            sw.WriteLine(temp2);
                        });

                        //Close wite file
                        sw.Close();
                        // fs.Close();

                    }
                    catch { }

                }

            }

        }

        // Compute and display frequency and max amplitude
        private void button2_Click(object sender, EventArgs e)
        {
            float frequency;
            float max_amplitude;
            // This is a rude calculate
            // adduming the period is from peak to peak
            float period;

            max_amplitude = (Values[0].Volt + Values[1].Volt) / 2;
            period = Values[1].Time - Values[0].Time;
            if (period < 0) period = -period;
            frequency = 1 / period;

            // Display
            textBox2.Text = frequency.ToString();
            textBox3.Text = max_amplitude.ToString();
        }
    }

    // We need this structure to make it convinient to us List
    class Record
    {
        public Record(float x, float y)
        {
            Time = x;
            Volt = y;
        }

        public float Time;
        public float Volt;
    };
}
